export default function Header() {
  return (
    <header className="header">
      <h1>Shop</h1>
    </header>
  );
}