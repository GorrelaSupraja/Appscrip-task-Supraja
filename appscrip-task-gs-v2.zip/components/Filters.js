export default function Filters() {
  return (
    <aside className="filters">
      <h2>Filters</h2>
      <label><input type="checkbox" /> Category 1</label>
      <label><input type="checkbox" /> Category 2</label>
    </aside>
  );
}