import Head from "next/head";
import Header from "../components/Header";
import ProductCard from "../components/ProductCard";
import Filters from "../components/Filters";

export default function Home({ products }) {
  return (
    <>
      <Head>
        <title>Product Listing Page</title>
        <meta name="description" content="Best products at best prices" />
      </Head>

      <Header />

      <div className="main">
        <Filters />
        <div className="products">
          {products.map((item) => (
            <ProductCard key={item.id} product={item} />
          ))}
        </div>
      </div>
    </>
  );
}

export async function getServerSideProps() {
  const res = await fetch("https://fakestoreapi.com/products");
  const products = await res.json();

  return {
    props: { products },
  };
}